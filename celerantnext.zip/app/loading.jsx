export default function LoadingPage() {
    return <div>

        Loading....
    </div>
}