import React from 'react'

const Notification = () => {
  return (
         
            <div className="col-lg-4 col-md-6 col-sm-6  notification">
              <p>Notification / Discount offer text goes here.</p>
            </div>
          
        
      
  );
}

export default Notification